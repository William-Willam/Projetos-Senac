package Sistema_Gerenciamento_Veiculo;

public interface Operacoes {
	void ligar();
	void desligar();
	void exibirInformacoes();
}
